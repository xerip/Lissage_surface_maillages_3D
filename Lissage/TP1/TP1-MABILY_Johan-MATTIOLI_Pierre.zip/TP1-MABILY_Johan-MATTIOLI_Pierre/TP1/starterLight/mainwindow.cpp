#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <cmath>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect ( ui->spinBox, SIGNAL(valueChanged(int)), this, SLOT(on_spinBox(int)) );

    connect ( ui->doubleSpinBox_h, SIGNAL(valueChanged(double)), this, SLOT(on_doubleSpinBox(double)) );
    connect ( ui->doubleSpinBox_lambda, SIGNAL(valueChanged(double)), this, SLOT(on_doubleSpinBox(double)) );
}

MainWindow::~MainWindow()
{
    delete ui;
}


////////////////////////////////// Fonctions /////////////////////////////////////////////////////

float MainWindow::faceArea(MyMesh* _mesh, int faceID)
{
    FaceHandle face_h = FaceHandle(faceID);

    // on enregistre les points de la face dans un QVector
    QVector<MyMesh::Point> points;
    for(MyMesh::FaceVertexIter curVer = _mesh->fv_iter(face_h); curVer.is_valid(); curVer++) {
        VertexHandle vertex_h = *curVer;
        points.push_back(_mesh->point(vertex_h));
    }

    return norm((points[1] - points[0]) % (points[2] - points[0])) / 2;
}

float MainWindow::aire_barycentrique(MyMesh* _mesh, int vertID) {
    VertexHandle vh = _mesh->vertex_handle(vertID);

    float area = 0;
    for(MyMesh::VertexFaceIter vfit = _mesh->vf_iter(vh); vfit.is_valid(); vfit++){
        area += faceArea(_mesh,(*vfit).idx());
    }

    return area / 3;
}

float MainWindow::angleEE(MyMesh* _mesh, int vertexID, int faceID)
{
    FaceHandle face_h = _mesh->face_handle(faceID);
    QVector<MyMesh::Point> points;
    MyMesh::Point point_origine;

    // on cherche le point d'origine
    for(MyMesh::FaceVertexIter curVer = _mesh->fv_begin(face_h); curVer.is_valid(); curVer++) {
        VertexHandle vertex_h = *curVer;

        if(vertex_h.idx() == vertexID) {
            point_origine = _mesh->point(vertex_h);
        }
        else {
            points.push_back(_mesh->point(vertex_h));
        }
    }

    MyMesh::Point vecteur1 = points[1] - point_origine;
    MyMesh::Point vecteur2 = points[0] - point_origine;
//    vecteur1.normalize();
//    vecteur2.normalize();
    return acos((vecteur1|vecteur2));
}

/*-------------------------------------------------------------------------
 * Recherche les sommets liés par 2 arretes appartenant respectivement
 * aux sommets d'indice @vertID et @vertIDV (dans un triangle)
 * Renvoie les 2 id des sommets et de leur faces.
 * ----------------------------------------------------------------------*/
void MainWindow::search_alpha_beta_data(MyMesh *_mesh, int vertID, int vertIDV,
                                      int &vertAlpha, int &vertBeta,
                                      int &faceAlpha, int &faceBeta)
{
    VertexHandle vhAlpha, vhBeta;
    VertexHandle vh = _mesh->vertex_handle(vertID);
    VertexHandle vhV = _mesh->vertex_handle(vertIDV);
    for (MyMesh::VertexEdgeCWIter ve_it=_mesh->ve_cwiter(vh); ve_it.is_valid(); ve_it++)
    {
        EdgeHandle eh = *ve_it;
        MyMesh::HalfedgeHandle heh0 = _mesh->halfedge_handle(eh, 0);
        MyMesh::HalfedgeHandle heh1 = _mesh->halfedge_handle(eh, 1);

        VertexHandle vhhe0 = _mesh->to_vertex_handle(heh0);
        VertexHandle vhhe1 = _mesh->to_vertex_handle(heh1);

        if (vhhe0.idx() == vhV.idx()    ||  vhhe1.idx() == vhV.idx())
        {
            //qDebug() << "\t\tok";
            FaceHandle fh0 = _mesh->face_handle(heh0);
            FaceHandle fh1 = _mesh->face_handle(heh1);

            for (MyMesh::FaceVertexIter fv_it=_mesh->fv_iter(fh0); fv_it.is_valid(); fv_it++)
            {
                vhAlpha = *fv_it;
                if (vhAlpha!=vh   &&  vhAlpha!=vhV) {
                    faceAlpha = fh0.idx();
                    vertAlpha = vhAlpha.idx();
                    break;
                }
            }
            for (MyMesh::FaceVertexIter fv_it=_mesh->fv_iter(fh1); fv_it.is_valid(); fv_it++)
            {
                vhBeta = *fv_it;
                if (vhBeta!=vh   &&  vhBeta!=vhV) {
                    faceBeta = fh1.idx();
                    vertBeta = vhBeta.idx();
                    break;
                }
            }
        }

    }
}


// cotangente -->  cot(alpha) = 1 / tan(alpha)
float MainWindow::calc_cot(MyMesh *_mesh, int vertID, int vertIDV)
{
    int vertAlpha = -1, vertBeta = -1;
    int faceAlpha = -1, faceBeta = -1;
    search_alpha_beta_data(_mesh, vertID, vertIDV,
                         vertAlpha, vertBeta,
                         faceAlpha, faceBeta);

    float alpha = angleEE(_mesh, vertAlpha, faceAlpha);
    float beta = angleEE(_mesh, vertBeta, faceBeta);

    float cA = 1.f / tan(alpha);
    float cB = 1.f / tan(beta);
    float myCotangente = cA + cB;

    return myCotangente;
}

MyMesh::Point MainWindow::approx_LB(MyMesh *_mesh, int vertID)
{
    VertexHandle vh = _mesh->vertex_handle(vertID);
    float aireBar = aire_barycentrique(_mesh, vh.idx());
    float calcAire = 1.f / (2.f * aireBar);
    MyMesh::Point sommeCot (0.f, 0.f, 0.f);

    int k=0;
    for (MyMesh::VertexVertexCWIter vv_it = _mesh->vv_cwiter(vh); vv_it.is_valid(); vv_it++)
    {
        VertexHandle vhV = *vv_it;
        MyMesh::Point pVh = _mesh->point(vh);
        MyMesh::Point pVhV = _mesh->point(vhV);
        float myCot = calc_cot(_mesh, vh.idx(), vhV.idx());
        MyMesh::Point myPoint = pVhV - pVh;
        if (k == 0) {
            sommeCot = myCot * myPoint;
        }
        else {
            sommeCot +=  myCot * myPoint;
        }
        k++;
    }
    MyMesh::Point res = calcAire * sommeCot;

    return res;
}

void MainWindow::lisser_LB_cot (MyMesh *_mesh, int nbIter, float h, float lambda)
{
    qDebug() << "<" << __FUNCTION__ << ">";

    vector<MyMesh::Point> pts;
    for (int i=0; i<nbIter; i++)
    {
        pts.clear();
        for (MyMesh::VertexIter v_it=mesh.vertices_begin(); v_it!=mesh.vertices_end(); ++v_it)
        {
            VertexHandle vh = *v_it;
            int vertID = vh.idx();
            MyMesh::Point myP = approx_LB(_mesh, vertID);
            pts.push_back(myP);
        }
        for (MyMesh::VertexIter v_it=mesh.vertices_begin(); v_it!=mesh.vertices_end(); ++v_it)
        {
            VertexHandle vh = *v_it;
            MyMesh::Point myP = _mesh->point(vh) + (pts[vh.idx()] * h * lambda);
            _mesh->set_point(vh, myP);
        }
    }

    qDebug() << "</" << __FUNCTION__ << ">";
}

void MainWindow::lisser_LB_uniform(MyMesh *_mesh, int nbIter, float h, float lambda)
{
    qDebug() << "<" << __FUNCTION__ << ">";
    vector<MyMesh::Point> pts;
    MyMesh::Point sommeP;

    for (int i=0; i<nbIter; i++)
    {
        //construct_Laplacien(_mesh);
        pts.clear();
        for (MyMesh::VertexIter v_it=mesh.vertices_begin(); v_it!=mesh.vertices_end(); ++v_it)
        {
            VertexHandle vh = *v_it;
            MyMesh::Point pVh = _mesh->point(vh);
            sommeP = MyMesh::Point(0.f, 0.f, 0.f);

            for (MyMesh::VertexVertexCWIter vv_it = _mesh->vv_cwiter(vh); vv_it.is_valid(); vv_it++)
            {
                VertexHandle vhV = *vv_it;
                MyMesh::Point pVhV = _mesh->point(vhV);
                MyMesh::Point myPoint = pVhV - pVh;
                sommeP = sommeP + myPoint;
            }
            pts.push_back(sommeP);
        }
        for (MyMesh::VertexIter v_it=mesh.vertices_begin(); v_it!=mesh.vertices_end(); ++v_it)
        {
            VertexHandle vh = *v_it;
            MyMesh::Point myP = _mesh->point(vh) + (pts[vh.idx()] * h * lambda);
            _mesh->set_point(vh, myP);
        }
    }
    qDebug() << "</" << __FUNCTION__ << ">";
}

double MainWindow::get_mij(MyMesh *_mesh, int i, int j)
{
    float wij = 0;

    // Diagonale
    if (i==j)
    {
        VertexHandle vh = _mesh->vertex_handle(i);
        for (MyMesh::VertexVertexCWIter vv_it = _mesh->vv_cwiter(vh); vv_it.is_valid(); vv_it++)
        {
            VertexHandle vhV = *vv_it;
            wij += calc_cot(_mesh, i, vhV.idx());
        }
        wij *= (-1);
    }
    // Pas diagonale... Eh ouais qui l'eu cru...
    else
    {
        VertexHandle vh = _mesh->vertex_handle(i);
        //MyMesh::Point p = _mesh->point(vh);
        for (MyMesh::VertexVertexCWIter vv_it = _mesh->vv_cwiter(vh); vv_it.is_valid(); vv_it++)
        {
            VertexHandle vhV = *vv_it;
            if (vhV.idx() == j) {
                wij = calc_cot(_mesh, i, j);
                break;
            }
        }
    }
    return wij;
}

void MainWindow::construct_Laplacien (MyMesh *_mesh)
{
    qDebug() << "<" << __FUNCTION__ << ">";

    L = Eigen::MatrixXd(_mesh->n_vertices(), _mesh->n_vertices());

    for (int y=0; y<L.rows(); y++)
    {
        for (int x=0; x<L.cols(); x++)
        {
           L(y, x) = get_mij(_mesh, x, y);
        }
    }

    qDebug() << "</" << __FUNCTION__ << ">";
}

void MainWindow::display_mesh(MyMesh *_mesh)
{
    GLuint* IndiceArray = new GLuint[_mesh->n_faces() * 3];
    MyMesh::ConstFaceIter fIt(_mesh->faces_begin()), fEnd(_mesh->faces_end());
    MyMesh::ConstFaceVertexIter fvIt;
    int i = 0;
    for (; fIt!=fEnd; ++fIt)
    {
        fvIt = _mesh->cfv_iter(*fIt);
        IndiceArray[i] = fvIt->idx(); i++; ++fvIt;
        IndiceArray[i] = fvIt->idx(); i++; ++fvIt;
        IndiceArray[i] = fvIt->idx(); i++;
    }
    GLfloat* colors = new GLfloat[_mesh->n_vertices() * 3];
    for(unsigned c = 0; c < _mesh->n_vertices() * 3; c = c + 3)
    {
        colors[c] = 0.5; colors[c+1] = 0.5; colors[c+2] = 0.5;
    }
    ui->widget->loadMesh((GLfloat*)_mesh->points(), colors, _mesh->n_vertices() * 3, IndiceArray, _mesh->n_faces() * 3);
}


//////////////////////////////////  Signaux //////////////////////////////////////////////////////

void MainWindow::on_pushButton_4_clicked()
{
    //construct_Laplacien(&mesh);
    lisser_LB_uniform(&mesh, nbIter, h, lambda);
    display_mesh(&mesh);
}

void MainWindow::on_pushButton_3_clicked()
{
    //construct_Laplacien(&mesh);
    lisser_LB_cot(&mesh, nbIter, h, lambda);
    display_mesh(&mesh);
}

void MainWindow::on_pushButton_clicked()
{
    // Cet exemple montre comment afficher un cube (sans passer par une structure de maillage) directement dans un MeshViewerWidget

    // une liste de sommets (x, y, z)
    GLfloat verts[24] = {
        -1.0f, 1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f, -1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f, -1.0f, 1.0f,
        1.0f, 1.0f, -1.0f,
        1.0f, -1.0f, -1.0f
    };

    // une liste de couleur (r, g, b)
    GLfloat cols[24] = {
        0.0f, 0.0f, 0.0f,
        1.0f, 0.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f,
        0.0f, 1.0f, 0.0f,
        0.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 0.0f,
        1.0f, 1.0f, 1.0f
    };

    // une liste de triangles coresspondants aux sommets de verts
    GLuint IndiceArray[36] = {
        0,1,2,    2,1,3,
        4,5,6,    6,5,7,
        3,1,5,    5,1,7,
        0,2,6,    6,2,4,
        6,7,0,    0,7,1,
        2,3,4,    4,3,5
    };

    ui->widget->loadMesh(verts, cols, 24, IndiceArray, 36);
}

void MainWindow::on_pushButton_2_clicked()
{
    // Cet exemple montre comment ouvrir un .obj, et l'afficher dans le MeshViewerWidget
    //OpenMesh::IO::read_mesh(mesh, "../meshFiles/bunnyLowPoly.obj");
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Mesh"), "", tr("Mesh Files (*.obj)"));
    OpenMesh::IO::read_mesh(mesh, fileName.toUtf8().constData());

    display_mesh(&mesh);
}

void MainWindow::on_spinBox(int value)
{
    qDebug() << __FUNCTION__ << "The event sender is" << sender();

    if (sender()->objectName() == "spinBox") {
        nbIter = value;
//        qDebug() << "nbIter = " << nbIter;
    }
}

void MainWindow::on_doubleSpinBox(double value)
{
    qDebug() << __FUNCTION__ << "The event sender is" << sender();

    if (sender()->objectName() == "doubleSpinBox_h") {
        h = value;
        qDebug() << "h = " << h;
    }
    else if (sender()->objectName() == "doubleSpinBox_lambda") {
        lambda = value;
//        qDebug() << "lmabda = " << lambda;
    }
}

