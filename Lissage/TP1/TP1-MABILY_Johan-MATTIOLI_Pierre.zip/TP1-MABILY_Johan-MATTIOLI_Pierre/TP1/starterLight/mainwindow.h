#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/Sparse>
#include <Eigen/Geometry>
#include <Eigen/Dense>

namespace Ui {
class MainWindow;
}

using namespace std;
using namespace OpenMesh;
using namespace OpenMesh::Attributes;

struct MyTraits : public OpenMesh::DefaultTraits{HalfedgeAttributes(OpenMesh::Attributes::PrevHalfedge);};
typedef OpenMesh::TriMesh_ArrayKernelT<MyTraits>  MyMesh;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    typedef Eigen::SparseMatrix<double> SparseMatrix;
    typedef Eigen::Triplet<double> Triplet;


    float faceArea(MyMesh* _mesh, int faceID);
    float aire_barycentrique(MyMesh* _mesh, int vertID);
    float angleEE(MyMesh* _mesh, int vertexID,  int faceID);

    void search_alpha_beta_data(MyMesh *_mesh, int vertID, int vertIDV, int &vertAlpha, int &vertBeta, int &faceAlpha, int &faceBeta);
    float calc_cot(MyMesh *_mesh, int vertID, int vertIDV);
    MyMesh::Point approx_LB(MyMesh *_mesh, int vertID);
    void lisser_LB_cot (MyMesh *_mesh, int nbIter, float h, float lambda);
    void lisser_LB_uniform (MyMesh *_mesh, int nbIter, float h, float lambda);
    double get_mij(MyMesh *_mesh, int i, int j);
    void construct_Laplacien (MyMesh *_mesh);


private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();

    void on_doubleSpinBox(double value);
    void on_spinBox(int value);

private:
    Ui::MainWindow *ui;

    MyMesh mesh;

    Eigen::MatrixXd L;

    int nbIter = 1;
    float h = 0.2f;
    float lambda = 0.2f;

    void display_mesh(MyMesh *_mesh);
};

#endif // MAINWINDOW_H
